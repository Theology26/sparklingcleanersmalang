// landing.js

// WhatsApp Booking Redirect
window.sendWhatsApp = function(event) {
    event.preventDefault();

    const name = document.getElementById('waName').value;
    const service = document.getElementById('waService').value;
    const notes = document.getElementById('waNotes').value;
    const delivery = document.getElementById('waDelivery').value;
    const address = document.getElementById('waAddress').value;

    if (!name || !service || !delivery) {
        alert("Nama, Layanan, dan Metode Penyerahan Wajib Diisi!");
        return;
    }

    if (delivery === 'Dijemput ke Alamat' && !address) {
        alert("Mohon isi detail alamat penjemputan Anda secara lengkap!");
        return;
    }

    const phone = "6285965957290"; // Nomor WA yang dituju
    let message = `Halo admin Sparkling Cleaners Malang! ✨%0A`;
    message += `Saya ingin melakukan booking layanan.%0A%0A`;
    message += `*Nama:* ${name}%0A`;
    message += `*Layanan:* Cuci ${service}%0A`;
    message += `*Metode:* ${delivery}%0A`;
    
    if (delivery === 'Dijemput ke Alamat') {
        message += `*Alamat Jemput:* ${address}%0A`;
    }
    
    if (notes) {
        message += `*Catatan/Keluhan:* ${notes}%0A`;
    }
    
    message += `%0AMohon info lebih lanjut mengenai estimasi waktu dan biaya. Terima kasih!`;

    const waURL = `https://wa.me/${phone}?text=${message}`;
    window.open(waURL, "_blank");
};

// Toggle Address Field based on Delivery Method
window.toggleAddressInput = function(value) {
    const addressField = document.getElementById('addressField');
    const addressInput = document.getElementById('waAddress');
    if (value === 'Dijemput ke Alamat') {
        addressField.style.display = 'block';
        addressInput.required = true;
    } else {
        addressField.style.display = 'none';
        addressInput.required = false;
        addressInput.value = '';
    }
};

// Order Tracking Simulation
window.simulateTracking = function() {
    const input = document.getElementById('trackInput').value;
    const msg = document.getElementById('trackingStatusMessage');
    const steps = document.querySelectorAll('.step');

    if (input.trim() === '') {
        alert("Silakan masukkan Nomor Order atau Nomor WA!");
        return;
    }

    // Reset Steps
    steps.forEach(step => step.classList.remove('active'));
    msg.style.display = 'block';
    msg.innerText = "Mencari data pesanan...";

    setTimeout(() => {
        // Simulasi logika track (Jika ada kata "siap", tahap 5)
        const lowerInput = input.toLowerCase();
        let currentStep = 2; // Default Cuci

        if (lowerInput.includes('kering')) currentStep = 3;
        else if (lowerInput.includes('finishing')) currentStep = 4;
        else if (lowerInput.includes('siap') || lowerInput.includes('selesai')) currentStep = 5;
        else if (lowerInput.includes('001') || lowerInput.includes('terima')) currentStep = 1;
        else currentStep = Math.floor(Math.random() * 5) + 1; // Random 1 to 5 untuk simulasi

        // Aktifkan step
        for (let i = 0; i < currentStep; i++) {
            steps[i].classList.add('active');
        }

        const statusLabels = [
            "Barang telah diterima di Workshop kami.",
            "Barang sedang dalam proses Deep Cleaning.",
            "Barang masuk tahap pengeringan sinar UV / angin.",
            "Tahap Finishing: Pemberian pewangi dan QC akhir.",
            "Barang SIAP DIAMBIL / dalam perjalanan diantar ke lokasi Anda!"
        ];

        msg.innerText = `Status Pesanan Anda: ${statusLabels[currentStep - 1]} ✨`;

    }, 800);
};

// Smooth Scrolling for Navbar Links
document.querySelectorAll('.nav-links a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth'
            });
        }
    });
});

// Modal Testimoni Logic
window.openTestimoniModal = function() {
    document.getElementById('testimoniModal').style.display = 'flex';
};

window.closeTestimoniModal = function() {
    document.getElementById('testimoniModal').style.display = 'none';
};

// Interactive Star Rating Logic
document.addEventListener('DOMContentLoaded', () => {
    const stars = document.querySelectorAll('#modalStarRating i');
    const ratingInput = document.getElementById('ratingValue');
    const ratingText = document.getElementById('ratingText');
    const textDesc = ["Sangat Kurang", "Kurang", "Cukup", "Puas", "Sangat Puas"];

    stars.forEach(star => {
        star.addEventListener('click', function() {
            const rating = parseInt(this.getAttribute('data-rating'));
            ratingInput.value = rating;
            ratingText.innerText = textDesc[rating - 1];
            ratingText.style.color = "var(--primary-navy)";
            
            stars.forEach(s => {
                if (parseInt(s.getAttribute('data-rating')) <= rating) {
                    s.classList.add('active');
                } else {
                    s.classList.remove('active');
                }
            });
        });
    });
});
