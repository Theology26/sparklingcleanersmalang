// dashboard.js

document.addEventListener('DOMContentLoaded', () => {

    // Check Authentication
    const userRole = localStorage.getItem('userRole');
    if (!userRole) {
        window.location.href = 'login.html'; // Redirect to login if not authenticated
        return;
    }

    // Set Initial Role UI securely based on login
    window.switchRole(userRole);
    window.switchRole(userRole);

    // Tab Switching Logic
    const menuItems = document.querySelectorAll('.menu-item[data-target]');
    const tabContents = document.querySelectorAll('.tab-content');

    menuItems.forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Remove active classes
            menuItems.forEach(m => m.classList.remove('active'));
            tabContents.forEach(t => t.classList.remove('active'));

            // Add active class
            this.classList.add('active');
            const targetId = this.getAttribute('data-target');
            document.getElementById(targetId).classList.add('active');
        });
    });

    // Dropzone Logic
    // Dropzone Logic Helper
    const initDropzone = (dropzoneId, inputId, nameId) => {
        const dropzone = document.getElementById(dropzoneId);
        const fileInput = document.getElementById(inputId);
        const fotoName = document.getElementById(nameId); // Optional

        if(dropzone && fileInput) {
            dropzone.addEventListener('click', () => fileInput.click());

            ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
                dropzone.addEventListener(eventName, (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                }, false);
            });

            ['dragenter', 'dragover'].forEach(eventName => {
                dropzone.addEventListener(eventName, () => {
                    dropzone.style.background = 'rgba(52, 152, 219, 0.2)';
                    dropzone.style.borderColor = 'var(--primary-navy)';
                }, false);
            });

            ['dragleave', 'drop'].forEach(eventName => {
                dropzone.addEventListener(eventName, () => {
                    dropzone.style.background = 'transparent';
                    dropzone.style.borderColor = 'rgba(255,255,255,0.4)';
                }, false);
            });

            dropzone.addEventListener('drop', (e) => {
                handleFiles(e.dataTransfer.files);
            }, false);

            fileInput.addEventListener('change', function() {
                handleFiles(this.files);
            });

            function handleFiles(files) {
                if (files.length > 0) {
                    if (fotoName) fotoName.innerText = "File Dipilih: " + files[0].name;
                    dropzone.style.borderColor = "#2ecc71"; // Success border (green)
                    dropzone.style.background = 'rgba(46, 204, 113, 0.1)';
                }
            }
        }
    };

    // Initialize both dropzones
    initDropzone('foto-dropzone', 'foto-input', 'foto-name');
    initDropzone('article-dropzone', 'article-foto-input', null);
});

// Role Switcher Logic (Mock)
window.switchRole = function(role) {
    const ownerSection = document.getElementById('ownerMenuSection');
    const activeRoleText = document.getElementById('activeRoleText');

    if (role === 'owner') {
        ownerSection.style.display = 'block';
        activeRoleText.innerText = "Mode: Owner (Superadmin)";
    } else {
        ownerSection.style.display = 'none';
        activeRoleText.innerText = "Mode: Admin Operasional";
        
        // If owner tab is active, redirect to orders tab
        const activeTabTarget = document.querySelector('.menu-item.active').getAttribute('data-target');
        if (['tab-stock', 'tab-catalog', 'tab-testimonials', 'tab-articles'].includes(activeTabTarget)) {
            document.querySelector('[data-target="tab-orders"]').click();
        }
    }
};

// Modal Logic
window.updateProgressModal = function(orderId) {
    const modal = document.getElementById('progressModal');
    const modalTitle = document.getElementById('modalTitle');
    
    modalTitle.innerText = `Update Progress Pesanan #${orderId}`;
    modal.style.display = 'flex';
};

window.closeProgressModal = function() {
    const modal = document.getElementById('progressModal');
    modal.style.display = 'none';
};

// Revenue Filter Simulation Logic
window.updateRevenueFilter = function(days) {
    const revTotal = document.getElementById('rev-total');
    const revOrders = document.getElementById('rev-orders');
    const revAvg = document.getElementById('rev-avg');
    
    // Base 7 days metrics
    const baseTotal = 3000000;
    const baseOrders = 70;
    const multiplier = days / 7;
    
    // Add random variance
    const total = Math.round(baseTotal * multiplier * (0.8 + Math.random() * 0.4));
    const orders = Math.round(baseOrders * multiplier * (0.8 + Math.random() * 0.4));
    const avg = Math.round(total / orders);
    
    revTotal.innerText = `Rp ${total.toLocaleString('id-ID')}`;
    revOrders.innerText = orders.toString();
    revAvg.innerText = `Rp ${avg.toLocaleString('id-ID')}`;
    
    // Animate bars update simulation
    const bars = document.querySelectorAll('.chart-bar');
    bars.forEach(bar => {
        bar.style.height = `${Math.floor(Math.random() * 70) + 20}%`;
    });
};

// Generic CRUD Modal Logic
window.openCrudModal = function(title) {
    const modal = document.getElementById('crudModal');
    const modalTitle = document.getElementById('crudModalTitle');
    
    if (modal && modalTitle) {
        modalTitle.innerText = title;
        modal.style.display = 'flex';
    }
};

window.closeCrudModal = function() {
    const modal = document.getElementById('crudModal');
    if (modal) {
        modal.style.display = 'none';
    }
};
